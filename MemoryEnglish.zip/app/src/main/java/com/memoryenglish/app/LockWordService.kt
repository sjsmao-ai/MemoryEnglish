package com.memoryenglish.app

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import java.util.Locale

class LockWordService : Service(), TextToSpeech.OnInitListener {
    private lateinit var wm: WindowManager
    private lateinit var progress: ProgressStore
    private var overlay: LinearLayout? = null
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var pendingSpeech: String? = null
    private val receiver = object: BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {
            when(intent?.action){
                Intent.ACTION_SCREEN_ON -> showWordOverlay()
                Intent.ACTION_SCREEN_OFF -> removeOverlay()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        progress=ProgressStore(this)
        tts=TextToSpeech(this,this)
        createChannel()
        val openIntent=Intent(this,MainActivity::class.java)
        val pi=PendingIntent.getActivity(this,0,openIntent,PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n=Notification.Builder(this,"memory_word_lock")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("기억영어 잠금화면 학습 중")
            .setContentText("화면을 켤 때 단어를 보여줍니다.")
            .setContentIntent(pi).setOngoing(true).build()
        startForeground(33,n)
        val f=IntentFilter().apply{addAction(Intent.ACTION_SCREEN_ON);addAction(Intent.ACTION_SCREEN_OFF)}
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, f)
        }
    }

    override fun onInit(status:Int){
        if(status==TextToSpeech.SUCCESS){
            val langResult = tts.setLanguage(Locale.US)
            tts.setSpeechRate(0.88f)
            tts.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            ttsReady = langResult != TextToSpeech.LANG_MISSING_DATA && langResult != TextToSpeech.LANG_NOT_SUPPORTED
            if(ttsReady){
                pendingSpeech?.let { text ->
                    pendingSpeech = null
                    speakWord(text)
                }
            }
        }
    }
    override fun onBind(intent:Intent?):IBinder?=null
    override fun onDestroy(){runCatching{unregisterReceiver(receiver)};removeOverlay();tts.stop();tts.shutdown();super.onDestroy()}

    private fun createChannel(){
        val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("memory_word_lock","잠금화면 단어 학습",NotificationManager.IMPORTANCE_LOW))
    }

    private fun chooseWord():WordEntry{
        val focus=progress.focusCategory
        val pool=if(focus!=null) WordData.words.filter{it.category==focus} else WordData.words
        val weighted=mutableListOf<WordEntry>()
        pool.forEach{w->repeat(1+minOf(progress.wordWrong(w.id),4)){weighted.add(w)}}
        return (weighted.ifEmpty{WordData.words}).random()
    }

    private fun showWordOverlay(){
        if(!progress.lockEnabled || !Settings.canDrawOverlays(this)) return
        removeOverlay()
        val w=chooseWord()
        val box=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER
            setPadding(dp(24),dp(24),dp(24),dp(24));setBackgroundColor(Color.argb(245,248,249,253))
        }
        fun tv(s:String,size:Float,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;gravity=Gravity.CENTER;setTextColor(Color.rgb(25,28,40));if(bold)setTypeface(typeface,Typeface.BOLD);setPadding(4,8,4,8)}
        box.addView(tv("기억영어",16f,true));box.addView(tv(w.english,38f,true));box.addView(tv(w.pronunciation,23f,true));box.addView(tv(w.korean,22f))
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        val know=Button(this).apply{text="✓ 알아";setOnClickListener{progress.markWordKnown(w.id);removeOverlay()}}
        val wrong=Button(this).apply{text="? 몰라";setOnClickListener{progress.markWordWrong(w.id);Toast.makeText(this@LockWordService,"다음에 더 자주 보여줄게요.",Toast.LENGTH_SHORT).show();removeOverlay()}}
        row.addView(know);row.addView(wrong);box.addView(row)
        box.addView(Button(this).apply{text="🔊 영어 발음";setOnClickListener{speakWord(w.english)}})
        box.addView(TextView(this).apply{text="아무 버튼도 누르지 않고 잠금을 풀면 미응답으로 처리됩니다.";textSize=12f;gravity=Gravity.CENTER;setTextColor(Color.DKGRAY);setPadding(4,14,4,2)})
        val lp=WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply{gravity=Gravity.CENTER}
        runCatching{wm.addView(box,lp);overlay=box}
    }

    private fun speakWord(text:String){
        if(!ttsReady){
            pendingSpeech = text
            Toast.makeText(this,"영어 발음을 준비하고 있어요. 잠시 후 자동으로 재생할게요.",Toast.LENGTH_SHORT).show()
            return
        }
        val params = Bundle().apply { putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC) }
        val result = tts.speak(text,TextToSpeech.QUEUE_FLUSH,params,"lock_word")
        if(result == TextToSpeech.ERROR){
            Toast.makeText(this,"발음 재생에 실패했어요. 휴대폰의 TTS 설정을 확인해 주세요.",Toast.LENGTH_SHORT).show()
        }
    }

    private fun removeOverlay(){overlay?.let{runCatching{wm.removeView(it)}};overlay=null}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}

