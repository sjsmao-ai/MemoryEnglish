package com.memoryenglish.app

import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer

class SimpleRecognitionListener(
    private val onFinal: (List<String>) -> Unit,
    private val onErrorResult: () -> Unit
) : RecognitionListener {
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onError(error: Int) = onErrorResult()
    override fun onResults(results: Bundle?) {
        onFinal(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: emptyList())
    }
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
}
