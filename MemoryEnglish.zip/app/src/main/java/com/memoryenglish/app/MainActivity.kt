package com.memoryenglish.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.util.Locale
import kotlin.math.max

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private lateinit var tts: TextToSpeech
    private lateinit var progress: ProgressStore
    private var atHome = true
    private var currentPatternId = 1
    private var currentSlot: WordEntry? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        progress = ProgressStore(this)
        showHome()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
            tts.setSpeechRate(0.88f)
        }
    }

    override fun onDestroy() {
        tts.stop(); tts.shutdown(); super.onDestroy()
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (!atHome) showHome() else super.onBackPressed()
    }

    private fun baseScreen(title: String, home: Boolean = false) {
        atHome = home
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(28))
            setBackgroundColor(Color.rgb(248,249,253))
        }
        scroll.addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)
        if (!home) secondaryButton("← 뒤로") { showHome() }
        root.addView(TextView(this).apply {
            text = title; textSize = 27f; setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.rgb(25,28,40)); setPadding(0,dp(8),0,dp(16))
        })
    }

    private fun showHome() {
        baseScreen("기억영어", true)
        card("매일 짧게, 계속 노출", "단어는 잠금화면에서 자주 만나고, 회화는 패턴을 바꿔가며 100번 성공 발화해요.")
        primaryButton("단어") { showWordHome() }
        primaryButton("회화") { showConversationHome() }
        secondaryButton("약점 복습") { showWeakHome() }
    }

    private fun showWordHome() {
        baseScreen("단어")
        val lockOn = progress.lockEnabled
        val focus = progress.focusCategory
        card("잠금화면 단어 노출", if (lockOn) "켜짐 · ${if(focus == null) "전체 자동 학습" else "집중: $focus"}" else "꺼짐")
        primaryButton(if (lockOn) "잠금화면 학습 끄기" else "잠금화면 학습 켜기") {
            if (lockOn) {
                stopService(Intent(this, LockWordService::class.java)); progress.lockEnabled = false; showWordHome()
            } else enableLockLearning()
        }
        secondaryButton("집중 노출 설정") { showFocusSettings() }
        section("주제별 단어")
        WordData.categories.forEach { category ->
            secondaryButton(category) { showCategory(category) }
        }
    }

    private fun enableLockLearning() {
        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("다른 앱 위에 표시 허용")
                .setMessage("잠금화면에 단어를 보여주려면 '다른 앱 위에 표시' 권한이 필요해요. 설정에서 기억영어를 허용해 주세요.")
                .setPositiveButton("설정 열기") { _, _ ->
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }.setNegativeButton("취소", null).show()
            return
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 301)
        }
        progress.lockEnabled = true
        startForegroundService(Intent(this, LockWordService::class.java))
        Toast.makeText(this, "잠금화면 단어 학습을 켰어요.", Toast.LENGTH_SHORT).show()
        showWordHome()
    }

    override fun onResume() {
        super.onResume()
        if (::progress.isInitialized && progress.lockEnabled && Settings.canDrawOverlays(this)) {
            runCatching { startForegroundService(Intent(this, LockWordService::class.java)) }
        }
    }

    private fun showFocusSettings() {
        baseScreen("집중 노출")
        card("사용 방법", "선택한 주제만 잠금화면에 집중적으로 보여줘요. 집중 노출을 끄면 즉시 원래 전체 학습으로 돌아갑니다.")
        if (progress.focusCategory != null) {
            card("현재 집중", progress.focusCategory!!)
            primaryButton("집중 노출 끄기 · 원래대로") { progress.focusCategory = null; showWordHome() }
        }
        WordData.categories.forEach { c ->
            secondaryButton("$c 집중") { progress.focusCategory = c; Toast.makeText(this, "$c 집중 노출로 변경했어요.", Toast.LENGTH_SHORT).show(); showWordHome() }
        }
    }

    private fun showCategory(category: String) {
        baseScreen(category)
        val words = WordData.words.filter { it.category == category }
        card("${words.size}개", "영어 · 한글 발음 · 뜻을 같이 익혀요.")
        primaryButton("이 주제 집중 노출") { progress.focusCategory = category; showWordHome() }
        words.forEach { w ->
            itemCard(w.english, "${w.pronunciation}\n${w.korean}")
        }
        if (words.isNotEmpty()) primaryButton("이 주제 빠르게 학습") { showManualWord(words, 0) }
    }

    private fun wordDisplayMode(w: WordEntry): WordDisplayMode {
        // 집중 노출은 빠르게 익히는 모드라 항상 영어·발음·뜻을 모두 보여줘요.
        if (progress.focusCategory != null) return WordDisplayMode.FULL
        // 일반 노출은 정답 여부와 무관하게 '실제로 본 횟수'를 기준으로 바꿉니다.
        // 처음 2회는 전체 표시, 3번째 노출부터 영어만/뜻만을 랜덤으로 보여줘요.
        return if (progress.wordSeen(w.id) < 2) WordDisplayMode.FULL
        else if (kotlin.random.Random.nextBoolean()) WordDisplayMode.ENGLISH_ONLY else WordDisplayMode.KOREAN_ONLY
    }

    private fun showManualWord(words: List<WordEntry>, index: Int) {
        if (words.isEmpty()) return
        val w = words[index % words.size]
        val mode = wordDisplayMode(w)
        if (progress.focusCategory == null) progress.markWordSeen(w.id)
        baseScreen("단어 빠른 학습")
        textCenter("${index + 1} / ${words.size}", 15f)

        when (mode) {
            WordDisplayMode.FULL -> {
                textCenter(w.english, 36f, true)
                textCenter(w.pronunciation, 22f, true)
                textCenter(w.korean, 21f)
                secondaryButton("🔊 영어 발음 듣기") { speak(w.english) }
                primaryButton("✓ 알아") {
                    progress.markWordKnown(w.id)
                    if (index + 1 >= words.size) showWordHome() else showManualWord(words, index + 1)
                }
                dangerButton("? 몰라") {
                    progress.markWordWrong(w.id)
                    Toast.makeText(this, "가까운 노출에서 더 자주 보여줄게요.", Toast.LENGTH_SHORT).show()
                    if (index + 1 >= words.size) showWordHome() else showManualWord(words, index + 1)
                }
            }
            WordDisplayMode.ENGLISH_ONLY -> {
                textCenter(w.english, 36f, true)
                textCenter(w.pronunciation, 22f, true)
                card("뜻 떠올리기", "영어를 보고 한글 뜻을 먼저 떠올려 보세요.")
                secondaryButton("정답 보기") { showWordAnswer(words, index, w) }
            }
            WordDisplayMode.KOREAN_ONLY -> {
                textCenter(w.korean, 30f, true)
                card("영어 떠올리기", "뜻을 보고 영어 단어를 먼저 떠올려 보세요.")
                secondaryButton("정답 보기") { showWordAnswer(words, index, w) }
            }
        }
    }

    private fun showWordAnswer(words: List<WordEntry>, index: Int, w: WordEntry) {
        baseScreen("단어 정답 확인")
        textCenter(w.english, 36f, true)
        textCenter(w.pronunciation, 22f, true)
        textCenter(w.korean, 21f)
        secondaryButton("🔊 영어 발음 듣기") { speak(w.english) }
        primaryButton("✓ 알아") {
            progress.markWordKnown(w.id)
            if (index + 1 >= words.size) showWordHome() else showManualWord(words, index + 1)
        }
        dangerButton("? 몰라") {
            progress.markWordWrong(w.id)
            Toast.makeText(this, "가까운 노출에서 더 자주 보여줄게요.", Toast.LENGTH_SHORT).show()
            if (index + 1 >= words.size) showWordHome() else showManualWord(words, index + 1)
        }
    }

    private fun showConversationHome() {
        baseScreen("회화")
        card("학습 방식", "한 패턴을 핵심 단어 약 10개로 바꿔 말하며 성공 100회를 채워요. 문장이 나오면 먼저 영어 발음을 들려준 뒤 직접 말합니다.")
        ConversationData.patterns.forEach { p ->
            val success = progress.patternSuccess(p.id)
            secondaryButton("${p.title}  ·  $success / 100") { currentPatternId = p.id; showConversationPractice(p) }
        }
    }

    private fun showConversationPractice(pattern: ConversationPattern) {
        baseScreen(pattern.title)
        val success = progress.patternSuccess(pattern.id)
        if (success >= 100) {
            card("완료 🎉", "이 패턴은 성공 발화 100회를 채웠어요. 원하면 계속 자유 연습할 수 있어요.")
        }
        val slot = chooseConversationSlot(pattern)
        currentSlot = slot
        val english = pattern.englishTemplate.format(slot.english)
        val korean = pattern.koreanTemplate.format(slot.korean)
        val pron = pattern.pronunciationTemplate.format(slot.pronunciation)
        textCenter("${minOf(success,100)} / 100", 17f, true)
        progressBar(minOf(success,100))
        textCenter(english, 31f, true)
        textCenter(pron, 21f, true)
        textCenter(korean, 20f)
        card("패턴", "${pattern.patternHint}\n문법은 따로 외우지 않고 이 문장을 바꿔 말하면서 익혀요.")
        speak(english)
        secondaryButton("🔊 영어 발음 다시 듣기") { speak(english) }
        val result = TextView(this).apply { textSize=16f; setTextColor(Color.DKGRAY); setPadding(dp(8),dp(12),dp(8),dp(8)) }
        root.addView(result)
        primaryButton("🎤 내가 말하기") {
            requestSpeech(english) { spoken, score ->
                if (score >= 80) {
                    progress.markPatternSuccess(pattern.id, slot.id)
                    result.text = "인식: $spoken\n정확도: $score%  ✓ 성공\n성공 횟수에 +1 됐어요."
                    root.postDelayed({ showConversationPractice(pattern) }, 900)
                } else {
                    progress.markPatternWrong(pattern.id, slot.id)
                    result.text = "인식: $spoken\n정확도: $score%\n이번 발화는 100회에 포함되지 않아요. 이 단어는 더 자주 나옵니다."
                }
            }
        }
        dangerButton("😣 이 문장이 어려워요") {
            progress.markPatternWrong(pattern.id, slot.id)
            Toast.makeText(this, "약점으로 표시했어요. 진행도에는 영향을 주지 않아요.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun chooseConversationSlot(pattern: ConversationPattern): WordEntry {
        val unfinished = pattern.slots.filter { progress.slotSuccess(pattern.id, it.id) < 10 }
        val base = if (unfinished.isNotEmpty()) unfinished else pattern.slots
        val weighted = mutableListOf<WordEntry>()
        base.forEach { w -> repeat(1 + minOf(progress.slotWrong(pattern.id, w.id), 4)) { weighted.add(w) } }
        return weighted.random()
    }

    private fun showWeakHome() {
        baseScreen("약점 복습")
        card("추가 연습", "자주 틀린 단어와 회화를 다시 보는 곳이에요. 여기서 연습한 것은 회화 100회 진행도나 정규 학습 기록에 더하지 않습니다.")
        val weakWords = WordData.words.filter { progress.wordWrong(it.id) > 0 }.sortedByDescending { progress.wordWrong(it.id) }.take(15)
        val weakSlots = ConversationData.patterns.flatMap { p -> p.slots.map { s -> Triple(p,s,progress.slotWrong(p.id,s.id)) } }.filter { it.third > 0 }.sortedByDescending { it.third }.take(15)
        section("단어")
        if (weakWords.isEmpty()) itemCard("아직 없음", "틀린 단어가 생기면 여기에 모여요.")
        weakWords.forEach { w -> itemCard(w.english, "${w.pronunciation} · ${w.korean} · 오답 ${progress.wordWrong(w.id)}회") }
        section("회화")
        if (weakSlots.isEmpty()) itemCard("아직 없음", "어려운 회화가 생기면 여기에 모여요.")
        weakSlots.forEach { (p,s,c) -> itemCard(p.englishTemplate.format(s.english), "${p.pronunciationTemplate.format(s.pronunciation)}\n${p.koreanTemplate.format(s.korean)} · 어려움 ${c}회") }
        if (weakWords.isNotEmpty() || weakSlots.isNotEmpty()) primaryButton("약점만 빠르게 보기") { showWeakPractice(weakWords, weakSlots, 0) }
    }

    private fun showWeakPractice(words: List<WordEntry>, slots: List<Triple<ConversationPattern,WordEntry,Int>>, index: Int) {
        val total = words.size + slots.size
        if (total == 0 || index >= total) { showWeakHome(); return }
        baseScreen("약점 추가 연습")
        textCenter("${index+1} / $total", 15f)
        if (index < words.size) {
            val w = words[index]
            textCenter(w.english, 34f, true); textCenter(w.pronunciation, 22f, true); textCenter(w.korean, 20f)
            secondaryButton("🔊 듣기") { speak(w.english) }
        } else {
            val (p,s,_) = slots[index - words.size]
            val en=p.englishTemplate.format(s.english)
            textCenter(en, 29f, true); textCenter(p.pronunciationTemplate.format(s.pronunciation), 21f, true); textCenter(p.koreanTemplate.format(s.korean), 19f)
            secondaryButton("🔊 듣기") { speak(en) }
        }
        primaryButton("다음") { showWeakPractice(words, slots, index+1) }
    }

    private fun requestSpeech(target: String, callback: (String, Int) -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 200)
            Toast.makeText(this, "마이크 권한을 허용한 뒤 다시 눌러주세요.", Toast.LENGTH_SHORT).show(); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { Toast.makeText(this,"음성 인식을 사용할 수 없어요.",Toast.LENGTH_SHORT).show(); return }
        val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        recognizer.setRecognitionListener(SimpleRecognitionListener(
            onFinal = { results ->
                val best = results.maxByOrNull { similarity(target,it) } ?: ""
                callback(best, similarity(target,best)); recognizer.destroy()
            },
            onErrorResult = { callback("인식 실패",0); recognizer.destroy() }
        ))
        recognizer.startListening(intent)
    }

    private fun similarity(a:String,b:String):Int {
        val x=normalize(a); val y=normalize(b); if(x.isEmpty()||y.isEmpty()) return 0
        val d=levenshtein(x,y); return ((1.0-d.toDouble()/max(x.length,y.length))*100).toInt().coerceIn(0,100)
    }
    private fun normalize(s:String)=s.lowercase(Locale.US).replace(Regex("[^a-z0-9 ]"),"").replace(Regex("\\s+")," ").trim()
    private fun levenshtein(a:String,b:String):Int {
        val prev=IntArray(b.length+1){it}; val cur=IntArray(b.length+1)
        for(i in 1..a.length){cur[0]=i;for(j in 1..b.length)cur[j]=minOf(cur[j-1]+1,prev[j]+1,prev[j-1]+if(a[i-1]==b[j-1])0 else 1);for(j in prev.indices)prev[j]=cur[j]}
        return prev[b.length]
    }

    private fun speak(text:String){ tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"study") }
    private fun card(title:String,body:String){ root.addView(LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(14));setBackgroundColor(Color.WHITE);addView(TextView(this@MainActivity).apply{text=title;textSize=18f;setTypeface(typeface,Typeface.BOLD);setTextColor(Color.rgb(35,38,52))});addView(TextView(this@MainActivity).apply{text=body;textSize=15f;setTextColor(Color.rgb(80,85,100));setPadding(0,dp(7),0,0)})},lpTop(10)) }
    private fun itemCard(title:String,body:String)=card(title,body)
    private fun section(s:String){root.addView(TextView(this).apply{text=s;textSize=19f;setTypeface(typeface,Typeface.BOLD);setPadding(0,dp(22),0,dp(4));setTextColor(Color.rgb(28,32,45))})}
    private fun textCenter(s:String,size:Float,bold:Boolean=false){root.addView(TextView(this).apply{text=s;textSize=size;gravity=Gravity.CENTER;if(bold)setTypeface(typeface,Typeface.BOLD);setTextColor(Color.rgb(28,32,45));setPadding(0,dp(9),0,dp(9))})}
    private fun progressBar(value:Int){ val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=value};root.addView(bar,lpTop(5)) }
    private fun primaryButton(label:String,action:()->Unit)=button(label,Color.rgb(49,87,213),Color.WHITE,action)
    private fun secondaryButton(label:String,action:()->Unit)=button(label,Color.WHITE,Color.rgb(45,55,80),action)
    private fun dangerButton(label:String,action:()->Unit)=button(label,Color.rgb(255,238,238),Color.rgb(180,35,35),action)
    private fun button(label:String,bg:Int,fg:Int,action:()->Unit):Button{val b=Button(this).apply{text=label;textSize=16f;setTextColor(fg);setBackgroundColor(bg);setPadding(dp(10),dp(9),dp(10),dp(9));setOnClickListener{action()}};root.addView(b,lpTop(10));return b}
    private fun lpTop(top:Int)=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply{topMargin=dp(top)}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}

enum class WordDisplayMode { FULL, ENGLISH_ONLY, KOREAN_ONLY }

class ProgressStore(c: Context) {
    private val p=c.getSharedPreferences("memory_english_v3",0)
    var lockEnabled:Boolean get()=p.getBoolean("lock_enabled",false); set(v){p.edit().putBoolean("lock_enabled",v).apply()}
    var focusCategory:String? get()=p.getString("focus_category",null); set(v){p.edit().putString("focus_category",v).apply()}
    fun wordWrong(id:String)=p.getInt("ww_$id",0)
    fun wordKnown(id:String)=p.getInt("wk_$id",0)
    // v0.9부터는 '노출 횟수'를 따로 저장합니다. 이전 버전 기록도 최대한 이어받도록
    // 기존 알아/몰라 횟수 합계를 최소 노출 횟수로 인정합니다.
    fun wordSeen(id:String)=maxOf(p.getInt("ws_$id",0), wordKnown(id)+wordWrong(id))
    fun markWordSeen(id:String){p.edit().putInt("ws_$id",wordSeen(id)+1).apply()}
    fun markWordWrong(id:String){p.edit().putInt("ww_$id",wordWrong(id)+1).apply()}
    fun markWordKnown(id:String){p.edit().putInt("wk_$id",wordKnown(id)+1).apply()}
    fun patternSuccess(id:Int)=p.getInt("ps_$id",0)
    fun slotSuccess(pid:Int,sid:String)=p.getInt("ss_${pid}_$sid",0)
    fun slotWrong(pid:Int,sid:String)=p.getInt("sw_${pid}_$sid",0)
    fun markPatternSuccess(pid:Int,sid:String){
        val total=patternSuccess(pid); val slot=slotSuccess(pid,sid)
        p.edit().putInt("ps_$pid",minOf(100,total+1)).putInt("ss_${pid}_$sid",slot+1).apply()
    }
    fun markPatternWrong(pid:Int,sid:String){p.edit().putInt("sw_${pid}_$sid",slotWrong(pid,sid)+1).apply()}
}

data class WordEntry(val id:String,val english:String,val pronunciation:String,val korean:String,val category:String)
data class ConversationPattern(val id:Int,val title:String,val patternHint:String,val englishTemplate:String,val pronunciationTemplate:String,val koreanTemplate:String,val slots:List<WordEntry>)

object WordData {
    val categories=listOf("회화 연계","요일","날짜·시간","숫자","필수 동사","음식·음료","가족·사람","장소·교통","감정·상태")
    private fun w(id:String,en:String,pr:String,ko:String,c:String)=WordEntry(id,en,pr,ko,c)
    val words=listOf(
        w("eat","eat","잇","먹다","회화 연계"),w("go","go","고우","가다","회화 연계"),w("sleep","sleep","슬립","자다","회화 연계"),w("study","study","스터디","공부하다","회화 연계"),w("walk","walk","워크","걷다","회화 연계"),w("drink","drink","드링크","마시다","회화 연계"),w("rest","rest","레스트","쉬다","회화 연계"),w("play","play","플레이","놀다/하다","회화 연계"),w("cook","cook","쿡","요리하다","회화 연계"),w("leave","leave","리브","떠나다","회화 연계"),
        w("monday","Monday","먼데이","월요일","요일"),w("tuesday","Tuesday","튜즈데이","화요일","요일"),w("wednesday","Wednesday","웬즈데이","수요일","요일"),w("thursday","Thursday","썰즈데이","목요일","요일"),w("friday","Friday","프라이데이","금요일","요일"),w("saturday","Saturday","새터데이","토요일","요일"),w("sunday","Sunday","선데이","일요일","요일"),
        w("today","today","투데이","오늘","날짜·시간"),w("tomorrow","tomorrow","투모로우","내일","날짜·시간"),w("yesterday","yesterday","예스터데이","어제","날짜·시간"),w("morning","morning","모닝","아침","날짜·시간"),w("afternoon","afternoon","애프터눈","오후","날짜·시간"),w("evening","evening","이브닝","저녁","날짜·시간"),w("night","night","나이트","밤","날짜·시간"),w("week","week","위크","주","날짜·시간"),w("month","month","먼스","달/월","날짜·시간"),w("year","year","이어","년","날짜·시간"),
        w("one","one","원","1","숫자"),w("two","two","투","2","숫자"),w("three","three","쓰리","3","숫자"),w("four","four","포어","4","숫자"),w("five","five","파이브","5","숫자"),w("six","six","식스","6","숫자"),w("seven","seven","세븐","7","숫자"),w("eight","eight","에이트","8","숫자"),w("nine","nine","나인","9","숫자"),w("ten","ten","텐","10","숫자"),w("hundred","hundred","헌드레드","100","숫자"),w("thousand","thousand","싸우전드","1,000","숫자"),
        w("want","want","원트","원하다","필수 동사"),w("need","need","니드","필요하다","필수 동사"),w("have","have","해브","가지다","필수 동사"),w("make","make","메이크","만들다","필수 동사"),w("take","take","테이크","가지고 가다/취하다","필수 동사"),w("get","get","겟","얻다/되다","필수 동사"),w("give","give","기브","주다","필수 동사"),w("know","know","노우","알다","필수 동사"),w("think","think","씽크","생각하다","필수 동사"),w("work","work","워크","일하다","필수 동사"),
        w("water","water","워터","물","음식·음료"),w("coffee","coffee","커피","커피","음식·음료"),w("rice","rice","라이스","밥/쌀","음식·음료"),w("bread","bread","브레드","빵","음식·음료"),w("meat","meat","미트","고기","음식·음료"),w("fruit","fruit","프루트","과일","음식·음료"),w("breakfast","breakfast","브렉퍼스트","아침식사","음식·음료"),w("lunch","lunch","런치","점심","음식·음료"),w("dinner","dinner","디너","저녁식사","음식·음료"),
        w("family","family","패밀리","가족","가족·사람"),w("mother","mother","마더","어머니","가족·사람"),w("father","father","파더","아버지","가족·사람"),w("wife","wife","와이프","아내","가족·사람"),w("husband","husband","허즈번드","남편","가족·사람"),w("friend","friend","프렌드","친구","가족·사람"),w("baby","baby","베이비","아기","가족·사람"),
        w("home","home","홈","집","장소·교통"),w("workplace","workplace","워크플레이스","직장","장소·교통"),w("school","school","스쿨","학교","장소·교통"),w("hospital","hospital","하스피털","병원","장소·교통"),w("station","station","스테이션","역","장소·교통"),w("bus","bus","버스","버스","장소·교통"),w("subway","subway","서브웨이","지하철","장소·교통"),w("car","car","카","자동차","장소·교통"),
        w("happy","happy","해피","행복한","감정·상태"),w("tired","tired","타이어드","피곤한","감정·상태"),w("hungry","hungry","헝그리","배고픈","감정·상태"),w("thirsty","thirsty","써스티","목마른","감정·상태"),w("busy","busy","비지","바쁜","감정·상태"),w("good","good","굿","좋은","감정·상태"),w("bad","bad","배드","나쁜","감정·상태"),w("okay","okay","오케이","괜찮은","감정·상태")
    )
    fun byId(id:String)=words.firstOrNull{it.id==id}
}

object ConversationData {
    private val slots=WordData.words.filter{it.category=="회화 연계"}
    val patterns=listOf(
        ConversationPattern(1,"Do you want to ~?","Do you want to + 동사원형?","Do you want to %s?","쥬 워너 %s?","%s할래?",slots),
        ConversationPattern(2,"I want to ~.","I want to + 동사원형","I want to %s.","아이 워너 %s.","나는 %s하고 싶어.",slots),
        ConversationPattern(3,"I'm going to ~.","I'm going to + 동사원형","I'm going to %s.","암 거너 %s.","나는 %s할 거야.",slots)
    )
}
