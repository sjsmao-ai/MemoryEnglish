package com.memoryenglish.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.Spannable
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.Locale
import kotlin.math.max
import kotlin.random.Random

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var root: LinearLayout
    private lateinit var tts: TextToSpeech
    private lateinit var store: StudyStore
    private val today get() = LocalDate.now().toEpochDay()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        store = StudyStore(this)
        store.seedIfNeeded(today)
        showHome()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
            tts.setSpeechRate(0.88f)
        }
    }

    override fun onDestroy() {
        tts.stop(); tts.shutdown()
        super.onDestroy()
    }

    private fun baseScreen(title: String): LinearLayout {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(28))
            setBackgroundColor(Color.rgb(248, 249, 253))
        }
        scroll.addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)
        root.addView(TextView(this).apply {
            text = title
            textSize = 25f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.rgb(25, 28, 40))
            setPadding(0, dp(4), 0, dp(14))
        })
        return root
    }

    private fun showHome() {
        baseScreen("기억영어")
        val dueWords = store.words.count { it.nextDue <= today }
        val duePhrases = store.phrases.count { it.nextDue <= today }
        val dueGrammar = store.grammar.count { it.nextDue <= today }

        card("오늘의 복습", "단어 ${dueWords}개 · 회화 ${duePhrases}문장 · 문법 ${dueGrammar}개\n단어·회화·문법은 따로 공부하지만, 오늘 학습에서는 서로 연결해서 반복해요.")
        primaryButton("오늘 학습 시작 (${dueWords + duePhrases + dueGrammar})") { startMixedStudy() }
        secondaryButton("단어") { showWordHome() }
        secondaryButton("회화") { startPhraseStudy(forceAll = true) }
        secondaryButton("문법") { showGrammarHome() }
        secondaryButton("약점 복습") { startWeakStudy() }
        secondaryButton("학습 목록 / 기억 단계") { showLibrary() }
        secondaryButton("복습 규칙 보기") { showRules() }

        val weak = (store.words.map { it.english to it.wrongCount } + store.phrases.map { it.english to it.wrongCount } + store.grammar.map { it.title to it.wrongCount })
            .filter { it.second > 0 }.sortedByDescending { it.second }.take(3)
        if (weak.isNotEmpty()) {
            val txt = weak.joinToString("\n") { "• ${it.first}  · 오답 ${it.second}회" }
            card("약점 노트", txt)
        }
    }

    private fun showRules() {
        baseScreen("반복 학습 규칙")
        secondaryButton("← 홈") { showHome() }
        card("단어", "Day 1~7 매일 → Day 15 → Day 20 → Day 25 → Day 30\nDay 30 통과 후 30일 뒤 재복습\n틀린 단어는 해당 단어만 Day 1부터 다시 시작")
        card("회화", "처음 Day 1~5는 영어 + 한글 뜻 + 음성 + 강세를 같이 노출\n그 뒤 Day 7 → 10 → 15 → 20 → 25 → 30\n이후 30일 간격 장기 복습")
        card("회화 오답", "한 번 틀리면 다음날 다시 출제\n연속 2번 틀리면 해당 문장만 Day 1으로 리셋\n발음/강세가 약한 문장도 가까운 날짜에 다시 출제")
        card("문법", "처음 Day 1~5는 뜻과 규칙을 예문으로 익혀요. 그 뒤에는 한글 → 영어, 빈칸, 직접 말하기 형태로 반복해요.\nDay 7 → 10 → 15 → 20 → 25 → 30 → 이후 30일 간격\n연속 오답이 쌓이면 그 문법만 Day 1부터 다시 시작해요.")
    }

    private fun showWordHome() {
        baseScreen("단어")
        secondaryButton("← 홈") { showHome() }
        val due = store.words.count { it.nextDue <= today }
        card("단어 학습", "단어는 회화/문법과 별도 영역으로 유지해요. 오늘 복습 ${due}개")
        primaryButton("오늘 단어 복습") {
            val q = store.words.filter { it.nextDue <= today }.shuffled().map { StudyTarget.WordT(it) }
            if (q.isEmpty()) Toast.makeText(this, "오늘 복습할 단어가 없어.", Toast.LENGTH_SHORT).show() else showStudyQueue(q, 0)
        }
        secondaryButton("단어 추가") { showAddWords() }
        secondaryButton("전체 단어 보기") { showLibrary() }
    }

    private fun showAddWords() {
        baseScreen("단어 추가")
        secondaryButton("← 홈") { showHome() }
        card("입력 방법", "한 줄에 하나씩 ‘영어 = 한글’ 형식으로 넣어줘.\n예) appointment = 약속\n한 번에 월~일 분량을 전부 넣어도 각 단어가 추가된 날부터 반복 일정이 시작돼.")
        val input = EditText(this).apply {
            hint = "appointment = 약속\nactually = 사실은\nprobably = 아마"
            minLines = 8
            gravity = Gravity.TOP
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(input, lpTop(10))
        primaryButton("단어 저장") {
            val lines = input.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }
            var added = 0
            lines.forEach { line ->
                val sep = when {
                    line.contains("=") -> "="
                    line.contains(":") -> ":"
                    line.contains("-") -> "-"
                    else -> null
                }
                if (sep != null) {
                    val parts = line.split(sep, limit = 2)
                    if (parts.size == 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) {
                        store.addWord(parts[0].trim(), parts[1].trim(), today); added++
                    }
                }
            }
            store.save()
            Toast.makeText(this, "${added}개 단어를 추가했어.", Toast.LENGTH_SHORT).show()
            showHome()
        }
    }

    private fun showLibrary() {
        baseScreen("학습 목록")
        secondaryButton("← 홈") { showHome() }
        section("단어 ${store.words.size}개")
        store.words.sortedBy { it.nextDue }.forEach { w ->
            itemCard(w.english, "${w.korean} · ${statusText(w.cycleStart, w.nextDue, w.wrongCount, true)}")
        }
        section("회화 ${store.phrases.size}문장")
        store.phrases.sortedBy { it.nextDue }.forEach { p ->
            itemCard(p.english, "${p.korean}\n${statusText(p.cycleStart, p.nextDue, p.wrongCount, false)}")
        }
        section("문법 ${store.grammar.size}개")
        store.grammar.sortedBy { it.nextDue }.forEach { g ->
            itemCard(g.title, "${g.pattern}\n${statusText(g.cycleStart, g.nextDue, g.wrongCount, false)}")
        }
    }

    private fun statusText(start: Long, next: Long, wrong: Int, word: Boolean): String {
        val cycleDay = max(1, (today - start + 1).toInt())
        val dueText = if (next <= today) "오늘 복습" else "${LocalDate.ofEpochDay(next)} 예정"
        return "현재 Day $cycleDay · $dueText · 누적 오답 ${wrong}회${if(word) "" else ""}"
    }

    private fun startMixedStudy() {
        val dueWords = store.words.filter { it.nextDue <= today }.shuffled()
        val duePhrases = store.phrases.filter { it.nextDue <= today }.shuffled()
        val dueGrammar = store.grammar.filter { it.nextDue <= today }.shuffled()
        val queue = mutableListOf<StudyTarget>()
        var wi = 0; var pi = 0; var gi = 0
        while (wi < dueWords.size || pi < duePhrases.size || gi < dueGrammar.size) {
            if (pi < duePhrases.size) queue.add(StudyTarget.PhraseT(duePhrases[pi++]))
            if (gi < dueGrammar.size) queue.add(StudyTarget.GrammarT(dueGrammar[gi++]))
            if (wi < dueWords.size) queue.add(StudyTarget.WordT(dueWords[wi++]))
        }
        if (queue.isEmpty()) {
            AlertDialog.Builder(this).setTitle("오늘 복습 완료").setMessage("오늘 예정된 학습은 다 끝났어. 회화 자유 연습은 언제든 할 수 있어.")
                .setPositiveButton("회화 연습") { _, _ -> startPhraseStudy(true) }
                .setNegativeButton("확인", null).show()
            return
        }
        showStudyQueue(queue, 0)
    }

    private fun startPhraseStudy(forceAll: Boolean) {
        val items = if (forceAll) store.phrases.shuffled() else store.phrases.filter { it.nextDue <= today }.shuffled()
        val q = items.map { StudyTarget.PhraseT(it) }
        if (q.isEmpty()) { Toast.makeText(this, "연습할 회화가 없어.", Toast.LENGTH_SHORT).show(); return }
        showStudyQueue(q, 0)
    }

    private fun showStudyQueue(queue: List<StudyTarget>, index: Int) {
        if (index >= queue.size) {
            store.save()
            baseScreen("오늘 학습 완료 🎉")
            card("잘했어", "오늘 예정된 복습을 끝냈어.\n틀린 항목은 기억 일정에 따라 자동으로 다시 나와.")
            primaryButton("홈으로") { showHome() }
            return
        }
        when (val target = queue[index]) {
            is StudyTarget.WordT -> showWordCard(target.word) { showStudyQueue(queue, index + 1) }
            is StudyTarget.PhraseT -> showPhraseCard(target.phrase) { showStudyQueue(queue, index + 1) }
            is StudyTarget.GrammarT -> showGrammarCard(target.grammar) { showStudyQueue(queue, index + 1) }
        }
    }

    private fun showWordCard(w: WordItem, done: () -> Unit) {
        baseScreen("단어 복습")
        val day = max(1, (today - w.cycleStart + 1).toInt())
        val expose = day <= 7
        textCenter("Day $day", 15f)
        textCenter(w.english, 32f, bold = true)
        if (expose) textCenter(w.korean, 22f)
        secondaryButton("🔊 발음 듣기") { speak(w.english) }
        if (!expose) {
            val reveal = secondaryButton("뜻 보기") { }
            reveal.setOnClickListener { reveal.text = w.korean }
        }
        primaryButton("✓ 맞았어") {
            ScheduleEngine.correctWord(w, today); store.save(); done()
        }
        dangerButton("✕ 틀렸어") {
            ScheduleEngine.wrongWord(w, today); store.save(); done()
        }
    }

    private fun showPhraseCard(p: PhraseItem, done: () -> Unit) {
        baseScreen("회화 복습")
        val day = max(1, (today - p.cycleStart + 1).toInt())
        val exposure = day <= 5
        val mode = if (exposure) PhraseMode.EXPOSURE else PhraseMode.entries.random()
        textCenter("Day $day · ${mode.label}", 15f)

        when (mode) {
            PhraseMode.EXPOSURE -> {
                stressText(p)
                textCenter(p.korean, 21f)
                card("처음 5일", "영어와 뜻을 같이 보고, 강세를 느끼면서 소리 내어 따라 말해.")
                speak(p.english)
            }
            PhraseMode.KO_TO_EN -> {
                textCenter(p.korean, 27f, bold = true)
                card("미션", "한글만 보고 영어로 말해봐.")
            }
            PhraseMode.EN_PRON -> {
                stressText(p)
                card("미션", "문장을 정확한 강세와 리듬으로 읽고 뜻도 떠올려봐.")
            }
            PhraseMode.AUDIO_ONLY -> {
                textCenter("🔊", 56f)
                card("미션", "화면에 문장은 안 보여줘. 소리만 듣고 영어 문장을 그대로 말한 뒤 뜻을 떠올려봐.")
                speak(p.english)
            }
            PhraseMode.SHADOWING -> {
                card("쉐도잉", "소리를 듣자마자 최대한 같은 리듬과 강세로 따라 말해.")
                speak(p.english)
            }
        }

        val result = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(dp(10), dp(12), dp(10), dp(8))
        }
        root.addView(result)

        secondaryButton("🎤 말하기 / 발음 체크") {
            requestSpeech(p.english) { spoken, score ->
                result.text = "인식: $spoken\n문장 정확도: ${score}%${if(score >= 80) "  ✓" else "  · 다시 연습 권장"}"
                if (score < 80) p.pronunciationWeak = true
            }
        }
        secondaryButton("정답 + 뜻 보기") {
            result.text = "${p.english}\n${p.korean}\n강세가 크게 표시된 단어를 조금 더 또렷하게 말해봐."
        }
        primaryButton("✓ 맞았어 / 발음 괜찮아") {
            ScheduleEngine.correctPhrase(p, today); p.pronunciationWeak = false; store.save(); done()
        }
        dangerButton("✕ 틀렸어 / 발음이 어려워") {
            ScheduleEngine.wrongPhrase(p, today); store.save(); done()
        }
    }

    private fun showGrammarHome() {
        baseScreen("문법")
        secondaryButton("← 홈") { showHome() }
        val due = store.grammar.count { it.nextDue <= today }
        card("회화로 배우는 문법", "문법책처럼 외우기보다 실제 문장을 바꾸면서 익혀요. 오늘 복습 ${due}개")
        primaryButton("오늘 문법 복습") {
            val q = store.grammar.filter { it.nextDue <= today }.shuffled().map { StudyTarget.GrammarT(it) }
            if (q.isEmpty()) Toast.makeText(this, "오늘 복습할 문법이 없어.", Toast.LENGTH_SHORT).show() else showStudyQueue(q, 0)
        }
        section("기초 문법")
        store.grammar.forEach { g ->
            itemCard(g.title, "${g.pattern}\n${g.explanation}")
        }
    }

    private fun startWeakStudy() {
        val q = mutableListOf<StudyTarget>()
        store.words.filter { it.wrongCount > 0 }.sortedByDescending { it.wrongCount }.take(8).forEach { q.add(StudyTarget.WordT(it)) }
        store.phrases.filter { it.wrongCount > 0 || it.pronunciationWeak }.sortedByDescending { it.wrongCount }.take(8).forEach { q.add(StudyTarget.PhraseT(it)) }
        store.grammar.filter { it.wrongCount > 0 }.sortedByDescending { it.wrongCount }.take(8).forEach { q.add(StudyTarget.GrammarT(it)) }
        if (q.isEmpty()) Toast.makeText(this, "아직 약점으로 등록된 항목이 없어.", Toast.LENGTH_SHORT).show() else showStudyQueue(q.shuffled(), 0)
    }

    private fun showGrammarCard(g: GrammarItem, done: () -> Unit) {
        baseScreen("문법 복습")
        val day = max(1, (today - g.cycleStart + 1).toInt())
        val exposure = day <= 5
        textCenter("Day $day · ${g.title}", 16f, bold = true)
        if (exposure) {
            card("핵심 규칙", "${g.pattern}\n${g.explanation}")
            val ex = g.examples.firstOrNull()
            if (ex != null) {
                textCenter(ex.english, 26f, bold = true)
                textCenter(ex.korean, 19f)
                secondaryButton("🔊 예문 듣기") { speak(ex.english) }
            }
            card("처음 5일", "규칙을 외우기보다 예문을 여러 번 보고 소리 내어 말하면서 구조를 익혀.")
        } else {
            val ex = g.examples.random()
            textCenter(ex.korean, 25f, bold = true)
            card("직접 만들어 보기", "위 문장을 영어로 말해봐. 핵심 패턴: ${g.pattern}")
            val result = TextView(this).apply { textSize = 16f; setTextColor(Color.DKGRAY); setPadding(dp(10), dp(12), dp(10), dp(8)) }
            root.addView(result)
            secondaryButton("🎤 영어로 말하기") {
                requestSpeech(ex.english) { spoken, score ->
                    result.text = "인식: $spoken\n문장 정확도: ${score}%"
                }
            }
            secondaryButton("정답 보기") { result.text = "${ex.english}\n${g.explanation}" }
        }
        primaryButton("✓ 이해했어 / 맞았어") { ScheduleEngine.correctGrammar(g, today); store.save(); done() }
        dangerButton("✕ 헷갈려 / 틀렸어") { ScheduleEngine.wrongGrammar(g, today); store.save(); done() }
    }

    private fun requestSpeech(target: String, callback: (String, Int) -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 200)
            Toast.makeText(this, "마이크 권한을 허용한 뒤 다시 눌러줘.", Toast.LENGTH_SHORT).show()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "이 휴대폰에서 음성 인식을 사용할 수 없어.", Toast.LENGTH_SHORT).show(); return
        }
        val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        recognizer.setRecognitionListener(SimpleRecognitionListener(
            onFinal = { results ->
                val best = results.maxByOrNull { similarity(target, it) } ?: ""
                callback(best, similarity(target, best)); recognizer.destroy()
            },
            onErrorResult = { callback("인식 실패", 0); recognizer.destroy() }
        ))
        recognizer.startListening(intent)
    }

    private fun similarity(a: String, b: String): Int {
        val x = normalize(a); val y = normalize(b)
        if (x.isEmpty() || y.isEmpty()) return 0
        val d = levenshtein(x, y)
        return ((1.0 - d.toDouble() / max(x.length, y.length)) * 100).toInt().coerceIn(0, 100)
    }

    private fun normalize(s: String) = s.lowercase(Locale.US).replace(Regex("[^a-z0-9 ]"), "").replace(Regex("\\s+"), " ").trim()
    private fun levenshtein(a: String, b: String): Int {
        val prev = IntArray(b.length + 1) { it }; val cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) cur[j] = minOf(cur[j-1] + 1, prev[j] + 1, prev[j-1] + if(a[i-1] == b[j-1]) 0 else 1)
            for (j in prev.indices) prev[j] = cur[j]
        }
        return prev[b.length]
    }

    private fun stressText(p: PhraseItem) {
        val s = SpannableString(p.english)
        p.stressWords.forEach { word ->
            var start = p.english.lowercase(Locale.US).indexOf(word.lowercase(Locale.US))
            while (start >= 0) {
                val end = start + word.length
                s.setSpan(RelativeSizeSpan(1.32f), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                s.setSpan(StyleSpan(Typeface.BOLD), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                start = p.english.lowercase(Locale.US).indexOf(word.lowercase(Locale.US), end)
            }
        }
        root.addView(TextView(this).apply {
            text = s; textSize = 27f; gravity = Gravity.CENTER; setTextColor(Color.rgb(24,31,52)); setPadding(0,dp(20),0,dp(16))
        })
    }

    private fun speak(text: String) { tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "study") }

    private fun card(title: String, body: String) {
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(14)); setBackgroundColor(Color.WHITE)
            addView(TextView(this@MainActivity).apply { text=title; textSize=18f; setTypeface(typeface,Typeface.BOLD); setTextColor(Color.rgb(35,38,52)) })
            addView(TextView(this@MainActivity).apply { text=body; textSize=15f; setTextColor(Color.rgb(80,85,100)); setPadding(0,dp(7),0,0) })
        }, lpTop(10))
    }
    private fun itemCard(title:String, body:String) = card(title, body)
    private fun section(s:String){ root.addView(TextView(this).apply{text=s;textSize=19f;setTypeface(typeface,Typeface.BOLD);setPadding(0,dp(22),0,dp(4))}) }
    private fun textCenter(s:String, size:Float, bold:Boolean=false){ root.addView(TextView(this).apply{text=s;textSize=size;gravity=Gravity.CENTER;if(bold)setTypeface(typeface,Typeface.BOLD);setTextColor(Color.rgb(28,32,45));setPadding(0,dp(10),0,dp(10))}) }

    private fun primaryButton(label:String, action:()->Unit): Button = button(label, Color.rgb(49,87,213), Color.WHITE, action)
    private fun secondaryButton(label:String, action:()->Unit): Button = button(label, Color.WHITE, Color.rgb(45,55,80), action)
    private fun dangerButton(label:String, action:()->Unit): Button = button(label, Color.rgb(255,238,238), Color.rgb(180,35,35), action)
    private fun button(label:String,bg:Int,fg:Int,action:()->Unit):Button{
        val b=Button(this).apply{text=label;textSize=16f;setTextColor(fg);setBackgroundColor(bg);setPadding(dp(10),dp(9),dp(10),dp(9));setOnClickListener{action()}}
        root.addView(b, lpTop(10)); return b
    }
    private fun lpTop(top:Int)=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply{topMargin=dp(top)}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}

sealed class StudyTarget {
    data class WordT(val word: WordItem): StudyTarget()
    data class PhraseT(val phrase: PhraseItem): StudyTarget()
    data class GrammarT(val grammar: GrammarItem): StudyTarget()
}

enum class PhraseMode(val label:String) {
    EXPOSURE("영어 + 뜻 같이 보기"),
    KO_TO_EN("한글 → 영어 말하기"),
    EN_PRON("영어 → 발음 + 뜻"),
    AUDIO_ONLY("소리만 듣기"),
    SHADOWING("원어민 따라 말하기")
}

data class WordItem(
    var id:Long, var english:String, var korean:String,
    var cycleStart:Long, var nextDue:Long, var wrongCount:Int=0,
    var consecutiveWrong:Int=0, var mastered:Boolean=false
)

data class PhraseItem(
    var id:Long, var english:String, var korean:String, var stressWords:List<String>,
    var cycleStart:Long, var nextDue:Long, var wrongCount:Int=0,
    var consecutiveWrong:Int=0, var mastered:Boolean=false, var pronunciationWeak:Boolean=false
)

data class GrammarExample(var english:String, var korean:String)

data class GrammarItem(
    var id:Long, var title:String, var pattern:String, var explanation:String,
    var examples:List<GrammarExample>, var cycleStart:Long, var nextDue:Long,
    var wrongCount:Int=0, var consecutiveWrong:Int=0, var mastered:Boolean=false
)

object ScheduleEngine {
    fun correctWord(w:WordItem, today:Long){
        w.consecutiveWrong=0
        val d=max(1,(today-w.cycleStart+1).toInt())
        val target=when{
            d<7 -> d+1
            d<15 -> 15
            d<20 -> 20
            d<25 -> 25
            d<30 -> 30
            else -> { w.mastered=true; -1 }
        }
        w.nextDue=if(target==-1) today+30 else max(today+1,w.cycleStart+target-1)
    }
    fun wrongWord(w:WordItem,today:Long){
        w.wrongCount++;w.consecutiveWrong++;w.mastered=false
        w.cycleStart=today+1;w.nextDue=today+1
    }
    fun correctPhrase(p:PhraseItem,today:Long){
        p.consecutiveWrong=0
        val d=max(1,(today-p.cycleStart+1).toInt())
        val target=when{
            d<5 -> d+1
            d<7 -> 7
            d<10 -> 10
            d<15 -> 15
            d<20 -> 20
            d<25 -> 25
            d<30 -> 30
            else -> {p.mastered=true;-1}
        }
        p.nextDue=if(target==-1) today+30 else max(today+1,p.cycleStart+target-1)
    }
    fun wrongPhrase(p:PhraseItem,today:Long){
        p.wrongCount++;p.consecutiveWrong++;p.mastered=false
        if(p.consecutiveWrong>=2){p.cycleStart=today+1;p.nextDue=today+1;p.consecutiveWrong=0}
        else p.nextDue=today+1
    }
    fun correctGrammar(g:GrammarItem,today:Long){
        g.consecutiveWrong=0
        val d=max(1,(today-g.cycleStart+1).toInt())
        val target=when{
            d<5 -> d+1
            d<7 -> 7
            d<10 -> 10
            d<15 -> 15
            d<20 -> 20
            d<25 -> 25
            d<30 -> 30
            else -> {g.mastered=true;-1}
        }
        g.nextDue=if(target==-1) today+30 else max(today+1,g.cycleStart+target-1)
    }
    fun wrongGrammar(g:GrammarItem,today:Long){
        g.wrongCount++;g.consecutiveWrong++;g.mastered=false
        if(g.consecutiveWrong>=2){g.cycleStart=today+1;g.nextDue=today+1;g.consecutiveWrong=0}
        else g.nextDue=today+1
    }
}

class StudyStore(private val a:Activity){
    private val pref=a.getSharedPreferences("memory_english",0)
    val words=mutableListOf<WordItem>()
    val phrases=mutableListOf<PhraseItem>()
    val grammar=mutableListOf<GrammarItem>()
    init{load()}

    fun seedIfNeeded(today:Long){
        if(phrases.isEmpty()){
            val seed=listOf(
                PhraseItem(1,"I'm going to take a bath.","나는 목욕하러 갈 거야.",listOf("going","bath"),today,today),
                PhraseItem(2,"I'm going to play soccer.","나는 축구하러 갈 거야.",listOf("play","soccer"),today,today),
                PhraseItem(3,"I'm going to eat.","나는 밥 먹으러 갈 거야.",listOf("going","eat"),today,today),
                PhraseItem(4,"I'm going to sleep.","나는 잘 거야.",listOf("going","sleep"),today,today),
                PhraseItem(5,"I'm not going to take a bath.","나는 목욕하러 가지 않을 거야.",listOf("not","bath"),today,today),
                PhraseItem(6,"I'm not going to eat.","나는 밥 먹으러 가지 않을 거야.",listOf("not","eat"),today,today),
                PhraseItem(7,"I couldn't go to the bathhouse.","나는 목욕탕에 가지 못했어.",listOf("couldn't","bathhouse"),today,today),
                PhraseItem(8,"I couldn't go out to eat.","나는 밥 먹으러 가지 못했어.",listOf("couldn't","eat"),today,today),
                PhraseItem(9,"I have to go now.","나 지금 가야 해.",listOf("have","go","now"),today,today),
                PhraseItem(10,"Do you want to eat?","밥 먹을래?",listOf("want","eat"),today,today)
            )
            phrases.addAll(seed);save()
        }
        if(grammar.isEmpty()){
            grammar.addAll(listOf(
                GrammarItem(101,"현재형","I + 동사원형","평소에 하는 일이나 습관을 말할 때 써요.",listOf(GrammarExample("I eat breakfast every day.","나는 매일 아침을 먹어."),GrammarExample("I go to work by bus.","나는 버스로 출근해.")),today,today),
                GrammarItem(102,"be going to","I'm going to + 동사원형","곧 하려는 일이나 계획을 말할 때 자연스럽게 많이 써요.",listOf(GrammarExample("I'm going to eat.","나는 밥 먹을 거야."),GrammarExample("I'm going to play soccer.","나는 축구하러 갈 거야.")),today,today),
                GrammarItem(103,"현재 부정","I don't + 동사원형","하지 않는다고 말할 때 don't 뒤에는 동사원형이 와요.",listOf(GrammarExample("I don't eat breakfast.","나는 아침을 먹지 않아."),GrammarExample("I don't go there often.","나는 거기에 자주 가지 않아.")),today,today),
                GrammarItem(104,"과거형","I + 과거동사","이미 끝난 일을 말할 때 동사를 과거형으로 바꿔요.",listOf(GrammarExample("I went to work.","나는 출근했어."),GrammarExample("I ate breakfast.","나는 아침을 먹었어.")),today,today),
                GrammarItem(105,"과거 부정","I didn't + 동사원형","didn't 자체가 과거를 나타내므로 뒤의 동사는 원형을 써요. didn't went가 아니라 didn't go예요.",listOf(GrammarExample("I didn't go to work.","나는 출근하지 않았어."),GrammarExample("I didn't eat breakfast.","나는 아침을 먹지 않았어.")),today,today),
                GrammarItem(106,"할 수 있다/없다","I can / can't + 동사원형","가능하거나 불가능한 일을 말할 때 can 또는 can't 뒤에 동사원형을 써요.",listOf(GrammarExample("I can do it.","나는 그걸 할 수 있어."),GrammarExample("I can't go today.","나는 오늘 갈 수 없어.")),today,today),
                GrammarItem(107,"하지 못했다","I couldn't + 동사원형","과거에 할 수 없었던 일을 말할 때 써요.",listOf(GrammarExample("I couldn't go to the bathhouse.","나는 목욕탕에 가지 못했어."),GrammarExample("I couldn't sleep last night.","나는 어젯밤 잠을 못 잤어.")),today,today),
                GrammarItem(108,"원한다","I want to + 동사원형","하고 싶은 일을 말할 때 가장 기본적으로 쓰는 패턴이에요.",listOf(GrammarExample("I want to eat.","나는 먹고 싶어."),GrammarExample("I want to go home.","나는 집에 가고 싶어.")),today,today),
                GrammarItem(109,"해야 한다","I have to + 동사원형","해야 하는 일을 말할 때 일상회화에서 아주 자주 써요.",listOf(GrammarExample("I have to go now.","나 지금 가야 해."),GrammarExample("I have to work tomorrow.","나는 내일 일해야 해.")),today,today),
                GrammarItem(110,"질문하기","Do you + 동사원형?","상대방의 행동이나 의사를 물을 때 쓰는 기본 질문이에요.",listOf(GrammarExample("Do you want to eat?","밥 먹을래?"),GrammarExample("Do you go there often?","너 거기 자주 가?")),today,today)
            ));save()
        }
    }

    fun addWord(en:String,ko:String,today:Long){
        if(words.any{it.english.equals(en,true)})return
        words.add(WordItem(System.currentTimeMillis()+words.size,en,ko,today,today))
    }

    private fun load(){
        try{
            val w=JSONArray(pref.getString("words","[]"))
            for(i in 0 until w.length()){val o=w.getJSONObject(i);words.add(WordItem(o.getLong("id"),o.getString("en"),o.getString("ko"),o.getLong("start"),o.getLong("due"),o.optInt("wrong"),o.optInt("cw"),o.optBoolean("master")))}
            val p=JSONArray(pref.getString("phrases","[]"))
            for(i in 0 until p.length()){
                val o=p.getJSONObject(i);val sa=o.optJSONArray("stress")?:JSONArray();val stress=mutableListOf<String>();for(j in 0 until sa.length())stress.add(sa.getString(j))
                phrases.add(PhraseItem(o.getLong("id"),o.getString("en"),o.getString("ko"),stress,o.getLong("start"),o.getLong("due"),o.optInt("wrong"),o.optInt("cw"),o.optBoolean("master"),o.optBoolean("pronWeak")))
            }
            val g=JSONArray(pref.getString("grammar","[]"))
            for(i in 0 until g.length()){
                val o=g.getJSONObject(i);val ea=o.optJSONArray("examples")?:JSONArray();val examples=mutableListOf<GrammarExample>()
                for(j in 0 until ea.length()){val e=ea.getJSONObject(j);examples.add(GrammarExample(e.getString("en"),e.getString("ko")))}
                grammar.add(GrammarItem(o.getLong("id"),o.getString("title"),o.getString("pattern"),o.getString("explain"),examples,o.getLong("start"),o.getLong("due"),o.optInt("wrong"),o.optInt("cw"),o.optBoolean("master")))
            }
        }catch(_:Exception){words.clear();phrases.clear();grammar.clear()}
    }
    fun save(){
        val w=JSONArray();words.forEach{w.put(JSONObject().put("id",it.id).put("en",it.english).put("ko",it.korean).put("start",it.cycleStart).put("due",it.nextDue).put("wrong",it.wrongCount).put("cw",it.consecutiveWrong).put("master",it.mastered))}
        val p=JSONArray();phrases.forEach{q->val s=JSONArray();q.stressWords.forEach{s.put(it)};p.put(JSONObject().put("id",q.id).put("en",q.english).put("ko",q.korean).put("stress",s).put("start",q.cycleStart).put("due",q.nextDue).put("wrong",q.wrongCount).put("cw",q.consecutiveWrong).put("master",q.mastered).put("pronWeak",q.pronunciationWeak))}
        val g=JSONArray();grammar.forEach{q->val e=JSONArray();q.examples.forEach{x->e.put(JSONObject().put("en",x.english).put("ko",x.korean))};g.put(JSONObject().put("id",q.id).put("title",q.title).put("pattern",q.pattern).put("explain",q.explanation).put("examples",e).put("start",q.cycleStart).put("due",q.nextDue).put("wrong",q.wrongCount).put("cw",q.consecutiveWrong).put("master",q.mastered))}
        pref.edit().putString("words",w.toString()).putString("phrases",p.toString()).putString("grammar",g.toString()).apply()
    }
}
